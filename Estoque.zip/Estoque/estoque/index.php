<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Login</title>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="#" method="post">
            <input type="email" name="email" placeholder="Digite seu E-mail" required>
            <input type="password" name="senha" placeholder="Digite sua senha" required>
            <input type="submit" value="Login">
            <a href="./php/cadastro.php">Cadastre-se</a>
        </form>
    </div>

    <?php
    include './php/conexao.php';

    session_start();

    if (isset($_POST["email"], $_POST["senha"])) {
        $email = $_POST["email"];
        $senha = $_POST["senha"];

        try {
            $comandoSQL = $conexao->prepare("SELECT * FROM usuarios WHERE email = :Email AND senha = :Senha");
            $comandoSQL->bindParam(":Email", $email);
            $comandoSQL->bindParam(":Senha", $senha);
            $comandoSQL->execute();

            if ($comandoSQL->rowCount() > 0) {
                $usuario = $comandoSQL->fetch(PDO::FETCH_ASSOC);
                $_SESSION['email'] = $usuario['email'];
                $_SESSION['nome'] = $usuario['nome'];
                $_SESSION['funcao'] = $usuario['funcao'];
                $_SESSION['id'] = $usuario['id'];

                echo '<script>window.location.href = "./php/paginainicial.php";</script>';
            } else {
                echo '<script>alert("Email ou senha incorretos."); window.location.href = "./index.php";</script>';
            }
        } catch (PDOException $e) {
            echo '<script>alert("Erro: ' . $e->getMessage() . '"); window.location.href = "./index.php";</script>';
        }
    }
    ?>
</body>
</html>

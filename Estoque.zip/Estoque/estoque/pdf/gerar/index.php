<?php
$conexao = new PDO("mysql:host=localhost;dbname=estoque", "root", "");

include '../dompdf/autoload.inc.php';

use Dompdf\Dompdf;

$stmt = $conexao->prepare("SELECT * FROM estoque");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pdf = new Dompdf();
$html = '
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    body {
        font-family: "Open Sans", sans-serif;
        font-size: 10px;
        margin: 20px;
    }
    h2 {
        color: #005f6b;
        text-align: center;
        font-size: 18px;
        margin-bottom: 15px;
        border-bottom: 2px solid #005f6b;
        padding-bottom: 5px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        padding: 10px;
        text-align: center;
        border: 1px solid #ddd;
        font-size: 11px;
    }
    th {
        background-color: #005f6b;
        color: white;
        font-weight: bold;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    tr:hover {
        background-color: #d8f1f2;
    }
    .footer {
        text-align: center;
        font-size: 9px;
        color: #777;
        margin-top: 20px;
        border-top: 1px solid #ddd;
        padding-top: 10px;
    }
</style>
</head>
<body>
    <h2>Balanço Geral</h2>
    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Dia</th>
                <th>Estoque Inicial</th>
                <th>Encomendas Iniciais</th>
                <th>Estoque Virtual Inicial</th>
                <th>Venda Efetiva</th>
                <th>Venda Perdida</th>
                <th>Demanda</th>
                <th>Compras</th>
                <th>Estoque Final</th>
                <th>Encomendas Finais</th>
                <th>Estoque Virtual Final</th>
                <th>Custo Unitário</th>
                <th>Custo Total</th>
            </tr>
        </thead>
        <tbody>';
        
foreach ($result as $row) {
    $html .= '<tr>
                <td>' . htmlspecialchars($row['produto_nome']) . '</td>
                <td>' . htmlspecialchars($row['dia']) . '</td>
                <td>' . htmlspecialchars($row['stk_inicial_er']) . '</td>
                <td>' . htmlspecialchars($row['stk_inicial_enc']) . '</td>
                <td>' . htmlspecialchars($row['stk_inicial_e_virt']) . '</td>
                <td>' . htmlspecialchars($row['venda_efetiva']) . '</td>
                <td>' . htmlspecialchars($row['venda_perdida']) . '</td>
                <td>' . htmlspecialchars($row['demanda']) . '</td>
                <td>' . htmlspecialchars($row['compras']) . '</td>
                <td>' . htmlspecialchars($row['stk_final_er']) . '</td>
                <td>' . htmlspecialchars($row['stk_final_enc']) . '</td>
                <td>' . htmlspecialchars($row['stk_final_e_virt']) . '</td>
                <td>' . htmlspecialchars($row['custo_unitario']) . '</td>
                <td>' . htmlspecialchars($row['custo_total']) . '</td>
              </tr>';
}

$html .= '  </tbody>
        </table>
        <div class="footer">Relatório gerado automaticamente em ' . date('d/m/Y') . '</div>
    </body>
</html>';


$pdf->loadHtml($html);
$pdf->setPaper('A4', 'landscape');

$options = $pdf->getOptions();
$options->setDefaultFont('Open Sans');

$pdf->render();
$pdf->stream();

<?php
session_start();

if (!isset($_SESSION['email'])) {
    echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
    exit;
}
include 'conexao.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM produtos WHERE id = :id";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$produto) {
        die('Produto não encontrado.');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $quantidade = $_POST['quantidade'];
    $fornecedor = $_POST['fornecedor'];
    $preco = $_POST['preco'];

    $sql = "UPDATE produtos SET nome = :nome, quantidade = :quantidade, fornecedor = :fornecedor, preco = :preco WHERE id = :id";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':quantidade', $quantidade, PDO::PARAM_INT);
    $stmt->bindParam(':fornecedor', $fornecedor);
    $stmt->bindParam(':preco', $preco);

    if ($stmt->execute()) {
        echo "Produto atualizado com sucesso!";
        header("Location: verificarProdutos.php");
        exit;
    } else {
        echo "Erro ao atualizar o produto.";
    }
}
if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "./paginainicial.php";</script>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/editarProduto.css">
    <title>Editar Produto</title>
</head>
<style>
   
</style>
<body>
    <div class="product-container">
        <h2>Editar Produto</h2>
        <form action="editarProduto.php?id=<?php echo $produto['id']; ?>" method="POST">
            <input type="hidden" name="id" value="<?php echo $produto['id']; ?>">
            
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($produto['nome']); ?>" required>

            <label for="quantidade">Quantidade:</label>
            <input type="number" name="quantidade" id="quantidade" value="<?php echo htmlspecialchars($produto['quantidade']); ?>" required>

            <label for="fornecedor">Fornecedor:</label>
            <input type="text" name="fornecedor" id="fornecedor" value="<?php echo htmlspecialchars($produto['fornecedor']); ?>" required>

            <label for="preco">Preço (R$):</label>
            <input type="text" name="preco" id="preco" value="<?php echo number_format($produto['preco'], 2, ',', '.'); ?>" required>

            <button type="submit">Atualizar Produto</button>
        </form>

    </div>
</body>
</html>
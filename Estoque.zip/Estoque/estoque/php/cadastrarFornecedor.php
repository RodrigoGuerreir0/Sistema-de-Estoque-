<?php
include 'conexao.php';

$alertMessage = "";
$alertMessageErro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = trim($_POST["nome"]);
    $cnpj = trim($_POST["cnpj"]);
    $endereco = trim($_POST["endereco"]);
    $telefone = trim($_POST["telefone"]);
    $email = trim($_POST["email"]);

    $sql = "INSERT INTO fornecedores (nome, cnpj, endereco, telefone, email) VALUES (:nome, :cnpj, :endereco, :telefone, :email)";

    try {
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':cnpj', $cnpj);
        $stmt->bindParam(':endereco', $endereco);
        $stmt->bindParam(':telefone', $telefone);
        $stmt->bindParam(':email', $email);

        if ($stmt->execute()) {
            $alertMessage = "Fornecedor cadastrado com sucesso!";
        } else {
            $alertMessageErro = "Erro ao cadastrar o fornecedor.";
        }
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) {
            $alertMessageErro = "Erro: CNPJ ou Email já cadastrado.";
        } else {
            $alertMessageErro = "Erro ao cadastrar o fornecedor: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/cadastrarFornecedor.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Fornecedor</title>

</head>
<style>
    .alert {
        display: <?php echo !empty($alertMessage) ? 'block' : 'none'; ?>;
    }

    .alert2 {
        display: <?php echo !empty($alertMessageErro) ? 'block' : 'none'; ?>;
    }

</style>

<body>
<div class="btnVoltar">
<button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs/home.png" alt=""></a></button>
    </div>
    <?php if (!empty($alertMessage)) : ?>
        <div class="alert" id="customAlert">
            <?php echo htmlspecialchars($alertMessage); ?>
            <button onclick="document.getElementById('customAlert').style.display='none';">&times;</button>
        </div>
    <?php endif; ?>

    <?php if (!empty($alertMessageErro)) : ?>
        <div class="alert2" id="customAlert2">
            <?php echo htmlspecialchars($alertMessageErro); ?>
            <button onclick="document.getElementById('customAlert2').style.display='none';">&times;</button>
        </div>
    <?php endif; ?>

    <div class="register-container">
        <h1>Cadastro de Fornecedor</h1>
        <form action="#" method="post">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="cnpj">CNPJ:</label>
            <input type="text" id="cnpj" name="cnpj" required maxlength="18">

            <label for="endereco">Endereço:</label>
            <input type="text" id="endereco" name="endereco">

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" maxlength="15">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <button type="submit">Cadastrar Fornecedor</button>
        </form>

        <div class="links">
            <a href="./inserirProduto.php">Inserir Produtos</a>
        </div>
    </div>
</body>
<script>
    function formatarCNPJ(cnpj) {
        cnpj = cnpj.replace(/\D/g, "");
        cnpj = cnpj.replace(/^(\d{2})(\d)/, "$1.$2");
        cnpj = cnpj.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
        cnpj = cnpj.replace(/\.(\d{3})(\d)/, ".$1/$2");
        cnpj = cnpj.replace(/(\d{4})(\d)/, "$1-$2");
        return cnpj;
    }

    function formatarTelefone(telefone) {
        telefone = telefone.replace(/\D/g, "");
        telefone = telefone.replace(/^(\d{2})(\d)/g, "($1) $2");
        if (telefone.length > 10) {
            telefone = telefone.replace(/(\d{5})(\d{4})$/, "$1-$2");
        } else {
            telefone = telefone.replace(/(\d{4})(\d{4})$/, "$1-$2");
        }
        return telefone;
    }

    document.addEventListener("DOMContentLoaded", function() {
        const cnpjInput = document.getElementById("cnpj");
        const telefoneInput = document.getElementById("telefone");

        cnpjInput.addEventListener("input", function() {
            this.value = formatarCNPJ(this.value);
        });

        telefoneInput.addEventListener("input", function() {
            this.value = formatarTelefone(this.value);
        });
    });

    setTimeout(function() {
        var alert = document.getElementById('customAlert');
        if (alert) {
            alert.style.display = 'none';
        }
    }, 3000);

    setTimeout(function() {
        var alert2 = document.getElementById('customAlert2');
        if (alert2) {
            alert2.style.display = 'none';
        }
    }, 3000);
</script>

</html>
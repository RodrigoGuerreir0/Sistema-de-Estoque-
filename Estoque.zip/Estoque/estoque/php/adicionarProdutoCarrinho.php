<?php
session_start();

if (!isset($_SESSION['email'])) {
  echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
  exit;
}

include 'conexao.php';

if (!isset($_SESSION['carrinho'])) {
  $_SESSION['carrinho'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === '1') {
  $produto_id = $_POST['produto_id'];
  $quantidade = $_POST['quantidade'];

  $sql = "SELECT * FROM produtos WHERE id = :id";
  $stmt = $conexao->prepare($sql);
  $stmt->bindParam(':id', $produto_id, PDO::PARAM_INT);
  $stmt->execute();
  $produto = $stmt->fetch(PDO::FETCH_ASSOC);

  if ($produto) {
    $produtoJaNoCarrinho = false;

    foreach ($_SESSION['carrinho'] as &$item) {
      if ($item['id'] === $produto['id']) {
        $item['quantidade'] += $quantidade; // Atualiza quantidade
        $produtoJaNoCarrinho = true;
        break;
      }
    }

    if (!$produtoJaNoCarrinho) {
      // Adicionar novo item ao carrinho
      $novoItem = [
        'id' => $produto['id'],
        'nome' => $produto['nome'],
        'preco' => $produto['preco'],
        'quantidade' => $quantidade
      ];
      $_SESSION['carrinho'][] = $novoItem; // Adiciona corretamente ao carrinho
    }

    // Retorna o último item atualizado ou o novo item adicionado
    $retornoProduto = $produtoJaNoCarrinho ? $item : $novoItem;

    echo json_encode([
      'status' => 'success',
      'message' => 'Produto adicionado ao carrinho com sucesso!',
      'produto' => $retornoProduto
    ]);
  } else {
    echo json_encode(['status' => 'error', 'message' => 'Produto não encontrado.']);
  }

  exit;
}

$sql = "SELECT * FROM produtos";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Adicionar Produtos ao Carrinho</title>
  <link rel="stylesheet" href="../css/adicionarProdutoCarrinho.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

  <style>
    .alert {
      display: <?php echo !empty($alertMessage) ? 'block' : 'none'; ?>;
      background-color: #00b4cc;
      color: white;
      padding: 15px;
      border-radius: 5px;
      width: 90%;
      max-width: 500px;
      margin: 20px auto;
      text-align: center;
      position: absolute;
      font-weight: bold;
      font-size: 1rem;
      left: 50%;
      bottom: 83%;
      transform: translateX(-50%)
    }

    .alert button {
      position: absolute;
      top: 5px;
      right: 10px;
      background: none;
      border: none;
      color: white;
      font-size: 1.2rem;
      cursor: pointer;
    }

    .alert button:hover {
      color: #008c9e;
    }
  </style>
</head>

<body>

  <header id="header">

    <nav id="nav">
      <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
        <span id="hambuguer"></span>
      </buttton>


      <?php if ($_SESSION['funcao'] == 'cliente') { ?>
        <ul id="menu" role="menu">
          <li><a href="../php/paginainicial.php">Pagina Inicial</a></li>
          <li><a href="../php/verCarrinho.php">Carrinho</a></li>
          <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
          <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
        </ul>
      <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
        <ul id="menu" role="menu">
          <li><a href="../php/paginainicial.php">Pagina Inicial</a></li>
          <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
          <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
          <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
          <li><a href="./logVendas.php">Histórico de Vendas</a></li>
          <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
          <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
          <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
        </ul>

      <?php } else {
        echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
        exit;
      } ?>
    </nav>
    <div id="header-title">Fazer Encomenda</div>
    <a href="./verCarrinho.php"><img class="carrinho" src="../imgs/carrinho.png" alt=""></a>

  </header>

  <div id="customAlert" class="alert" style="display: none;">
    <span id="alertMessage"></span>
    <button onclick="closeAlert()">×</button>
  </div>


  <?php if (!empty($alertMessage)): ?>
    <div class="alert"><?php echo $alertMessage; ?></div>
  <?php endif; ?>

  <div class="product-container">
    <?php foreach ($produtos as $produto): ?>
      <div class="product-card">
        <h3 class="product-name"><?= $produto['nome'] ?></h3>
        <p class="product-price">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></p>
        <form onsubmit="addToCart(event, <?= $produto['id'] ?>)">
          <div class="quantity-selector">
            <button type="button" class="quantity-btn" onclick="decreaseQuantity(<?= $produto['id'] ?>)">-</button>
            <input class="inputQTD" type="number" id="quantity-<?= $produto['id'] ?>" value="1" min="1">
            <button type="button" class="quantity-btn" onclick="increaseQuantity(<?= $produto['id'] ?>)">+</button>
          </div>
          <button type="submit" class="add-to-cart">Adicionar ao Carrinho</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>


  <script>
    function decreaseQuantity(id) {
      const input = document.getElementById(`quantity-${id}`);
      let value = parseInt(input.value);
      if (value > 1) input.value = value - 1;
    }

    function increaseQuantity(id) {
      const input = document.getElementById(`quantity-${id}`);
      input.value = parseInt(input.value) + 1;
    }

    setTimeout(function() {
      var alert = document.getElementById('customAlert');
      if (alert) {
        alert.style.display = 'none';
      }
    }, 3000);


    function showCustomAlert(message) {
      const alert = document.getElementById('customAlert');
      const alertMessage = document.getElementById('alertMessage');
      alertMessage.textContent = message;
      alert.style.display = 'block';

      setTimeout(() => {
        alert.style.display = 'none';
      }, 3000);
    }

    function closeAlert() {
      const alert = document.getElementById('customAlert');
      alert.style.display = 'none';
    }

    function addToCart(event, productId) {
      event.preventDefault();

      const quantityInput = document.getElementById(`quantity-${productId}`);
      const quantity = parseInt(quantityInput.value);

      if (quantity < 1) {
        showCustomAlert('Quantidade inválida!');
        return;
      }

      fetch('adicionarProdutoCarrinho.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            ajax: '1',
            produto_id: productId,
            quantidade: quantity,
          }),
        })
        .then((response) => response.json())
        .then((data) => {
          if (data.status === 'success') {
            showCustomAlert(data.message);
          } else {
            showCustomAlert(data.message || 'Erro ao adicionar produto ao carrinho.');
          }
        })
        .catch((error) => {
          console.error('Erro:', error);
          showCustomAlert('Erro ao processar a requisição.');
        });
    }

    function decreaseQuantity(id) {
      const input = document.getElementById(`quantity-${id}`);
      let value = parseInt(input.value);
      if (value > 1) input.value = value - 1;
    }

    function increaseQuantity(id) {
      const input = document.getElementById(`quantity-${id}`);
      input.value = parseInt(input.value) + 1;
    }
  </script>

</body>
<script src="../script/hamburguer.js"></script>

</html>
<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['id'])) {
    echo "Usuário não autenticado!";
    exit;
}

$usuario_id = $_SESSION['id'];

$sql = "SELECT e.id, p.nome AS produto_nome, e.quantidade, e.status, e.data_pedido 
        FROM pedidos AS e
        JOIN produtos AS p ON e.produto_id = p.id
        WHERE e.usuario_id = :usuario_id
        ORDER BY e.data_pedido DESC";
$stmt = $conexao->prepare($sql);
$stmt->bindParam(':usuario_id', $usuario_id);
$stmt->execute();
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/statusPedidos.css">
    <title>Status dos Pedidos</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

</head>

<body>

    <header id="header">

        <nav id="nav">
            <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
                <span id="hambuguer"></span>
            </buttton>


            <?php if ($_SESSION['funcao'] == 'cliente') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Pagina Inicial</a></li>
                    <li><a href="../php/verCarrinho.php">Carrinho</a></li>
                    <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                </ul>
            <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Pagina Inicial</a></li>
                    <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
                    <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
                    <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
                    <li><a href="./logVendas.php">Histórico de Vendas</a></li>
                    <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                    <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
                    <li><a href="./encomendarProduto.php">Encomendar Produtos</a></li>

                </ul>

            <?php } else {
                echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
                exit;
            } ?>
        </nav>
        <div id="header-title">Histórico de Pedidos</div>
        <a href="./verCarrinho.php"><img class="carrinho" src="../imgs/carrinho.png" alt=""></a>

    </header>
    <main>

        <?php if (count($pedidos) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID do Pedido</th>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidos as $pedido): ?>
                        <tr>
                            <td><?php echo $pedido['id']; ?></td>
                            <td><?php echo htmlspecialchars($pedido['produto_nome']); ?></td>
                            <td><?php echo $pedido['quantidade']; ?></td>
                            <td class="<?php
                                        if ($pedido['status'] == 'confirmada') {
                                            echo 'status-confirmada';
                                        } elseif ($pedido['status'] == 'cancelada') {
                                            echo 'status-cancelada';
                                        } else {
                                            echo 'status-pendente';
                                        }
                                        ?>">
                                <?php echo ucfirst($pedido['status']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Você ainda não tem pedidos registrados.</p>
        <?php endif; ?>

        <div class="links">
            <a href="./paginainicial.php">Voltar à Página Inicial</a>
        </div>
    </main>

</body>
<script src="../script/hamburguer.js"></script>

</html>
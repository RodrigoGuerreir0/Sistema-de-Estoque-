<?php
include 'conexao.php';

$alertMessage = "";

session_start();

if (!isset($_SESSION['email'])) {
    echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
    exit;
}

if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "./paginainicial.php";</script>';
    exit;
}

$usuario_id = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $produto_id = $_POST['produto_id'];
    $quantidade_encomendada = intval($_POST['quantidade']);

    if ($quantidade_encomendada > 0) {
        $sql = "SELECT id FROM produtos WHERE id = :id";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':id', $produto_id, PDO::PARAM_INT);
        $stmt->execute();
        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($produto) {
            $dataSelect = $conexao->prepare("SELECT data_atual FROM controle_data ORDER BY data_atual DESC LIMIT 1");
            $dataSelect->execute();
            if ($dataSelect->rowCount() > 0) {
                $row = $dataSelect->fetch(PDO::FETCH_ASSOC);
                $DiaAtual = $row['data_atual'];
            } else {
                $DiaAtual = date("Y-m-d");
            }

            $data_chegada = date('Y-m-d', strtotime($DiaAtual . ' +4 days'));

            $sql = "INSERT INTO historico_encomendas 
                    (produto_id, usuario_id, CompraAutomatica, quantidade, statusDaEncomenda, data_encomenda, data_chegada) 
                    VALUES (:produto_id, :usuario_id, :CompraAutomatica, :quantidade, :statusDaEncomenda, :data_encomenda, :data_chegada)";
            $stmt = $conexao->prepare($sql);
            $compraAutomatica = 'Não';
            $statusDaEncomenda = 'A caminho';

            $stmt->bindParam(':produto_id', $produto_id, PDO::PARAM_INT);
            $stmt->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
            $stmt->bindParam(':CompraAutomatica', $compraAutomatica, PDO::PARAM_STR);
            $stmt->bindParam(':quantidade', $quantidade_encomendada, PDO::PARAM_INT);
            $stmt->bindParam(':statusDaEncomenda', $statusDaEncomenda, PDO::PARAM_STR);
            $stmt->bindParam(':data_encomenda', $DiaAtual);
            $stmt->bindParam(':data_chegada', $data_chegada);
            $stmt->execute();

            $alertMessage = "Produto encomendado com sucesso! Será entregue em $data_chegada.";
        } else {
            $alertMessage = "Produto não encontrado!";
        }
    } else {
        $alertMessage = "A quantidade deve ser um número positivo!";
    }
}

$sql = "SELECT * FROM produtos";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Encomendar Produto</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/encomendarProduto.css">
    <style>
        .alert {
            display: <?php echo !empty($alertMessage) ? 'block' : 'none'; ?>;
            background-color: #521945;
            color: white;
            padding: 15px;
            border-radius: 5px;
            width: 90%;
            max-width: 500px;
            margin: 20px auto;
            text-align: center;
            position: absolute;
            font-weight: bold;
            font-size: 1rem;
            left: 50%;
            bottom: 83%;
            transform: translateX(-50%)
        }

        .alert button {
            position: absolute;
            top: 5px;
            right: 10px;
            background: none;
            border: none;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
        }

        .alert button:hover {
            color: #2b0d24;
        }
    </style>
</head>

<body>
    <header id="header">

        <nav id="nav">
            <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
                <span id="hambuguer"></span>
            </buttton>


            <?php if ($_SESSION['funcao'] == 'cliente') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Página Inicial</a></li>
                    <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                    <li><a href="../php/verCarrinho.php">Carrinho</a></li>
                </ul>
            <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
                <ul id="menu" role="menu">
                    <!-- <li><a href="../php/paginainicial.php">Página Inicial</a></li> -->
                    <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
                    <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
                    <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
                    <li><a href="./logVendas.php">Histórico de Vendas</a></li>
                    <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
                    <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
                    <li><a href="./encomendarProduto.php">Encomendar Produtos</a></li>

                </ul>

            <?php } else {
                echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
                exit;
            } ?>
        </nav>
        <div id="header-title">Encomendar Produto</div>
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs//home.png" alt=""></a></button>


    </header>
    <main>

        <?php if (!empty($alertMessage)) : ?>
            <div class="alert" id="customAlert">
                <?php echo htmlspecialchars($alertMessage); ?>
                <button onclick="document.getElementById('customAlert').style.display='none';">&times;</button>
            </div>
        <?php endif; ?>
        <div class="espaco">

            <form action="encomendarProduto.php" method="POST">
                <label for="produto">Selecione o produto:</label>
                <select name="produto_id" id="produto" required>
                    <option value="">Selecione...</option>
                    <?php foreach ($produtos as $produto): ?>
                        <option value="<?php echo $produto['id']; ?>"><?php echo $produto['nome']; ?> (Quantidade: <?php echo $produto['quantidade']; ?>)</option>
                    <?php endforeach; ?>
                </select>

                <label for="quantidade">Quantidade para encomendar:</label>
                <input type="number" name="quantidade" id="quantidade" min="1" required>

                <button type="submit">Encomendar</button>
            </form>

            <div class="links">
                <a href="./verificarProdutos.php">Estoque de produtos</a>
            </div>
        </div>
    </main>
    <script>
        setTimeout(function() {
            var alert = document.getElementById('customAlert');
            if (alert) {
                alert.style.display = 'none';
            }
        }, 3000);
    </script>
</body>
<script src="../script/hamburguer.js"></script>

</html>
<?php
session_start();
include 'conexao.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM produtos WHERE id = :id";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo '<script>
            window.location.href = "verificarProdutos.php";
        </script>';
    } else {
        echo '<script>alert("Erro ao excluir o produto.");</script>';
    }
} else {
    echo '<script>alert("Produto não encontrado.");</script>';
}

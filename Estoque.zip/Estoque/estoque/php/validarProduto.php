<?php 
include 'conexao.php';

$nome = $_POST['nome'];
$quantidade = $_POST['quantidade'];
$fornecedor = $_POST['fornecedor'];
$preco = $_POST['preco'];

try {
    $query = "SELECT COUNT(*) FROM produtos WHERE nome = :nome";
    $stmt = $conexao->prepare($query);
    $stmt->bindParam(':nome', $nome);
    $stmt->execute();

    $count = $stmt->fetchColumn();

    if ($count > 0) {
        echo "Erro: Já existe um produto com o nome '$nome'.";
    } else {
        $insertQuery = "INSERT INTO produtos (nome, quantidade, fornecedor, preco) VALUES (:nome, :quantidade, :fornecedor, :preco)";
        $insertStmt = $conexao->prepare($insertQuery);
        
        $insertStmt->bindParam(':nome', $nome);
        $insertStmt->bindParam(':quantidade', $quantidade);
        $insertStmt->bindParam(':fornecedor', $fornecedor);
        $insertStmt->bindParam(':preco', $preco);
        
        $insertStmt->execute();
        
        echo "Produto '$nome' cadastrado com sucesso!";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/cadastro.css">
    <title>Cadastro de Usuário</title>
    
</head>
<body>
    <div class="register-container">
        <h2>Cadastro de Usuário</h2>
        <form action="validarcadastro.php" method="post">
            <input type="text" name="nome" placeholder="Digite seu nome" required>
            <input type="text" name="sobrenome" placeholder="Digite seu sobrenome" required>
            <input type="email" name="email" placeholder="Digite seu E-mail" required>
            <input type="password" name="senha" placeholder="Digite sua senha" required>
            <input type="password" name="confirmarsenha" placeholder="Confirme sua senha" required>
            <input type="submit" value="Enviar">
            <a href="../index.php">Login</a>
        </form>
    </div>
</body>
</html>

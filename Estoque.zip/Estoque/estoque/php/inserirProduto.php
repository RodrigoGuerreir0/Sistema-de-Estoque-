<?php
session_start();
include 'conexao.php';
$alertMessage = "";
$alertMessageErro = "";


if (!isset($_SESSION['email'])) {
    echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
    exit;
}
if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "./paginainicial.php";</script>';
    exit;
}

try {
    $sql = "SELECT id, nome FROM fornecedores";
    $stmt = $conexao->prepare($sql);
    $stmt->execute();
    $fornecedores = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erro ao buscar fornecedores: " . $e->getMessage();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nome'], $_POST['quantidade'], $_POST['fornecedor'], $_POST['preco'])) {
    $nome = $_POST['nome'];
    $quantidade = $_POST['quantidade'];
    $fornecedor = $_POST['fornecedor'];
    $preco = $_POST['preco'];

    try {
        $query = "SELECT COUNT(*) FROM produtos WHERE nome = :nome";
        $stmt = $conexao->prepare($query);
        $stmt->bindParam(':nome', $nome);
        $stmt->execute();

        $count = $stmt->fetchColumn();

        if ($count > 0) {
            $$alertMessageErro = "Erro: Já existe um produto com o nome '$nome'.";
        } else {
            $insertQuery = "INSERT INTO produtos (nome, quantidade, fornecedor, preco) VALUES (:nome, :quantidade, :fornecedor, :preco)";
            $insertStmt = $conexao->prepare($insertQuery);

            $insertStmt->bindParam(':nome', $nome);
            $insertStmt->bindParam(':quantidade', $quantidade);
            $insertStmt->bindParam(':fornecedor', $fornecedor);
            $insertStmt->bindParam(':preco', $preco);

            $insertStmt->execute();
            $alertMessage = "Produto '$nome' cadastrado com sucesso!";
        }
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
}
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/inserirProdutos.css">
    <title>Cadastro de Produtos</title>
</head>
<style>
    .alert {
        display: <?php echo !empty($alertMessage) ? 'block' : 'none'; ?>;
        background-color: #FFF;
        color: #008c9e;
        padding: 15px;
        border-radius: 5px;
        width: 90%;
        max-width: 500px;
        margin: 20px auto;
        text-align: center;
        position: absolute;
        font-weight: bold;
        font-size: 1rem;
        left: 50%;
        bottom: 83%;
        transform: translateX(-50%)
    }

    .alert button {
        position: absolute;
        top: 5px;
        right: 10px;
        background: none;
        border: none;
        color: #008c9e;
        font-size: 1.2rem;
        cursor: pointer;
    }

    .alert button:hover {
        color: #2b0d24;
    }

    .alert2 {
        display: <?php echo !empty($alertMessage) ? 'block' : 'none'; ?>;
        background-color: #FFF;
        color: #FF0000;
        padding: 15px;
        border-radius: 5px;
        width: 90%;
        max-width: 500px;
        margin: 20px auto;
        text-align: center;
        position: absolute;
        font-weight: bold;
        font-size: 1rem;
        left: 50%;
        bottom: 83%;
        transform: translateX(-50%)
    }

    .alert2 button {
        position: absolute;
        top: 5px;
        right: 10px;
        background: none;
        border: none;
        color: #FF0000;
        font-size: 1.2rem;
        cursor: pointer;
    }

    .alert2 button:hover {
        color: #2b0d24;
    }
</style>

<body>
    <div class="btnVoltar">
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs/home.png" alt=""></a></button>
    </div>
    <?php if (!empty($alertMessage)) : ?>
        <div class="alert" id="customAlert">
            <?php echo htmlspecialchars($alertMessage); ?>
            <button onclick="document.getElementById('customAlert').style.display='none';">&times;</button>
        </div>
    <?php endif; ?>

    <?php if (!empty($alertMessageErro)) : ?>
        <div class="alert2" id="customAlert2">
            <?php echo htmlspecialchars($alertMessageErro); ?>
            <button onclick="document.getElementById('customAlert2').style.display='none';">&times;</button>
        </div>
    <?php endif; ?>
    <div class="product-container">
        <h2>Cadastro de Produtos</h2>
        <form action="#" method="post">
            <input type="text" name="nome" placeholder="Nome do produto" required>
            <input type="number" name="quantidade" placeholder="Quantidade do produto" required>
            <input type="number" step="0.01" name="preco" placeholder="Digite o preço do produto" required>
            <br>
            <label for="fornecedor">Fornecedor:</label>
            <select name="fornecedor" id="fornecedor" required>
                <option value="">Selecione um fornecedor</option>
                <?php foreach ($fornecedores as $fornecedor): ?>
                    <option value="<?= $fornecedor['nome']; ?>"><?= htmlspecialchars($fornecedor['nome']); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Cadastrar Produto">
        </form>

      

        <div>
            <a href="./cadastrarFornecedor.php">Cadastrar Fornecedor</a>
        </div>
    </div>
</body>
<script>
    setTimeout(function() {
        var alert = document.getElementById('customAlert');
        if (alert) {
            alert.style.display = 'none';
        }
    }, 3000);

    setTimeout(function() {
        var alert2 = document.getElementById('customAlert2');
        if (alert2) {
            alert2.style.display = 'none';
        }
    }, 3000);
</script>

</html>
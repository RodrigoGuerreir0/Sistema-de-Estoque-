<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['carrinho']) || empty($_SESSION['carrinho'])) {
    echo "Carrinho vazio!";
    exit;
}

if (!isset($_SESSION['id'])) {
    echo "Usuário não autenticado!";
    exit;
}

$usuario_id = $_SESSION['id'];

foreach ($_SESSION['carrinho'] as $item) {
    $produto_id = $item['id'];
    $quantidade = $item['quantidade'];

    $sql_estoque = "SELECT quantidade FROM produtos WHERE id = :produto_id";
    $stmt_estoque = $conexao->prepare($sql_estoque);
    $stmt_estoque->bindParam(':produto_id', $produto_id);
    $stmt_estoque->execute();
    $produto = $stmt_estoque->fetch(PDO::FETCH_ASSOC);

    if ($produto && $produto['quantidade'] >= $quantidade) {
        $sql = "INSERT INTO pedidos (produto_id, usuario_id, quantidade, status, data_pedido) 
                VALUES (:produto_id, :usuario_id, :quantidade, 'confirmada', :data_pedido)";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':produto_id', $produto_id);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':quantidade', $quantidade);

        $dataSelect = $conexao->prepare("SELECT data_atual FROM controle_data ORDER BY data_atual DESC LIMIT 1");
        $dataSelect->execute();
        if ($dataSelect->rowCount() > 0) {
            $row = $dataSelect->fetch(PDO::FETCH_ASSOC);
            $DiaAtual = $row['data_atual'];
        } else {
            $DiaAtual = date("Y-m-d");
        }
        $stmt->bindParam(':data_pedido', $DiaAtual);

        $stmt->execute();

        $nova_quantidade = $produto['quantidade'] - $quantidade;
        $sql_update = "UPDATE produtos SET quantidade = :nova_quantidade WHERE id = :produto_id";
        $stmt_update = $conexao->prepare($sql_update);
        $stmt_update->bindParam(':nova_quantidade', $nova_quantidade);
        $stmt_update->bindParam(':produto_id', $produto_id);
        $stmt_update->execute();

        $produtoDaDemanda = "SELECT SUM(quantidade) FROM pedidos WHERE produto_id = :produto_id AND data_pedido = :dia";
        $demandaDeProdutosStmt = $conexao->prepare($produtoDaDemanda);
        $demandaDeProdutosStmt->execute([':produto_id' => $produto_id, ':dia' => $DiaAtual]);
        $demanda = (int)$demandaDeProdutosStmt->fetchColumn();
        $demandaDeProdutosStmt->closeCursor();
        $novaDemanda = $demanda;

        $updateDemanda = "UPDATE estoque SET demanda = :demanda, venda_efetiva = :venda_efetiva, venda_perdida = :venda_perdida, stk_final_er = :stk_final_er, stk_final_e_virt = :stk_final_e_virt WHERE produto_id = :produto_id AND dia = :dia";
        $updateDemandaStmt = $conexao->prepare($updateDemanda);

        $updateDemandaStmt->bindParam(':demanda', $novaDemanda);
        $updateDemandaStmt->bindParam(':produto_id', $produto_id);
        $updateDemandaStmt->bindParam(':dia', $DiaAtual);

        $VendaEfetivaSTMT = "SELECT SUM(quantidade) as total_vendido FROM pedidos WHERE status = 'confirmada' AND produto_id = :produto_id AND data_pedido = :dia";
        $VendaEfetivaSTMT = $conexao->prepare($VendaEfetivaSTMT);
        $VendaEfetivaSTMT->bindParam(':produto_id', $produto_id);
        $VendaEfetivaSTMT->bindParam(':dia', $DiaAtual);
        $VendaEfetivaSTMT->execute();

        if ($VendaEfetivaSTMT->rowCount() > 0) {
            $row = $VendaEfetivaSTMT->fetch(PDO::FETCH_ASSOC);
            $vendaEfetiva = $row['total_vendido'];

            $updateDemandaStmt->bindParam(':venda_efetiva', $vendaEfetiva);
        }

        $venda_perdida = $novaDemanda - $vendaEfetiva;

        $updateDemandaStmt->bindParam(':venda_perdida', $venda_perdida);

        $compras = 0;

        $stokFinalDoDiaSTMT = "SELECT stk_inicial_er FROM estoque WHERE produto_id = :produto_id AND dia = :dia";
        $stokFinalDoDiaSTMT = $conexao->prepare($stokFinalDoDiaSTMT);
        $stokFinalDoDiaSTMT->bindParam(':produto_id', $produto_id);
        $stokFinalDoDiaSTMT->bindParam(':dia', $DiaAtual);
        $stokFinalDoDiaSTMT->execute();

        if ($stokFinalDoDiaSTMT->rowCount() > 0) {
            $row2 = $stokFinalDoDiaSTMT->fetch(PDO::FETCH_ASSOC);
            $stokInicialDoDia = $row2['stk_inicial_er'];
        }

        $stokFinalDoDia = $stokInicialDoDia - $novaDemanda;

        $updateDemandaStmt->bindParam(':stk_final_er', $stokFinalDoDia);

        $stokFinalDoDiaSTMT = "SELECT stk_final_enc FROM estoque WHERE produto_id = :produto_id AND dia = :dia";
        $stokFinalDoDiaSTMT = $conexao->prepare($stokFinalDoDiaSTMT);
        $stokFinalDoDiaSTMT->bindParam(':produto_id', $produto_id);
        $stokFinalDoDiaSTMT->bindParam(':dia', $DiaAtual);
        $stokFinalDoDiaSTMT->execute();

        if ($stokFinalDoDiaSTMT->rowCount() > 0) {
            $row3 = $stokFinalDoDiaSTMT->fetch(PDO::FETCH_ASSOC);
            $stokEncomendasFinal = $row3['stk_final_enc'];
        }

        $stk_final_e_virt = $stokFinalDoDia + $stokEncomendasFinal;

        $updateDemandaStmt->bindParam(':stk_final_e_virt', $stk_final_e_virt);

        $updateDemandaStmt->execute();
        $updateDemandaStmt->closeCursor();
    } else {
        $sql = "INSERT INTO pedidos (produto_id, usuario_id, quantidade, status, data_pedido) 
                VALUES (:produto_id, :usuario_id, :quantidade, 'cancelada', :data_pedido)";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':produto_id', $produto_id);
        $stmt->bindParam(':usuario_id', $usuario_id);
        $stmt->bindParam(':quantidade', $quantidade);

        $dataSelect = $conexao->prepare("SELECT data_atual FROM controle_data ORDER BY data_atual DESC LIMIT 1");
        $dataSelect->execute();
        if ($dataSelect->rowCount() > 0) {
            $row = $dataSelect->fetch(PDO::FETCH_ASSOC);
            $DiaAtual = $row['data_atual'];
        } else {
            $DiaAtual = date("Y-m-d");
        }
        $stmt->bindParam(':data_pedido', $DiaAtual);

        $stmt->execute();

        $produtoDaDemanda = "SELECT SUM(quantidade) FROM pedidos WHERE produto_id = :produto_id AND data_pedido = :dia";
        $demandaDeProdutosStmt = $conexao->prepare($produtoDaDemanda);
        $demandaDeProdutosStmt->execute([':produto_id' => $produto_id, ':dia' => $DiaAtual]);
        $demanda = (int)$demandaDeProdutosStmt->fetchColumn();
        $demandaDeProdutosStmt->closeCursor();
        $novaDemanda = $demanda;

        $updateDemanda = "UPDATE estoque SET demanda = :demanda, venda_efetiva = :venda_efetiva, venda_perdida = :venda_perdida stk_final_e_virt = :stk_final_e_virt WHERE produto_id = :produto_id AND dia = :dia";
        $updateDemandaStmt = $conexao->prepare($updateDemanda);
        $updateDemandaStmt->bindParam(':demanda', $novaDemanda);
        $updateDemandaStmt->bindParam(':produto_id', $produto_id);
        $updateDemandaStmt->bindParam(':dia', $DiaAtual);

        $VendaEfetivaSTMT = "SELECT SUM(quantidade) as total_vendido FROM pedidos WHERE status = 'confirmada' AND produto_id = :produto_id AND data_pedido = :dia";
        $VendaEfetivaSTMT = $conexao->prepare($VendaEfetivaSTMT);
        $VendaEfetivaSTMT->bindParam(':produto_id', $produto_id);
        $VendaEfetivaSTMT->bindParam(':dia', $DiaAtual);
        $VendaEfetivaSTMT->execute();

        if ($VendaEfetivaSTMT->rowCount() > 0) {
            $row = $VendaEfetivaSTMT->fetch(PDO::FETCH_ASSOC);
            $vendaEfetiva = $row['total_vendido'];

            $updateDemandaStmt->bindParam(':venda_efetiva', $vendaEfetiva);
        }

        $venda_perdida = $novaDemanda - $vendaEfetiva;

        $updateDemandaStmt->bindParam(':venda_perdida', $venda_perdida);

        $compras = 0;

        $stokFinalDoDiaSTMT = "SELECT stk_inicial_er FROM estoque WHERE produto_id = :produto_id AND dia = :dia";
        $stokFinalDoDiaSTMT = $conexao->prepare($stokFinalDoDiaSTMT);
        $stokFinalDoDiaSTMT->bindParam(':produto_id', $produto_id);
        $stokFinalDoDiaSTMT->bindParam(':dia', $DiaAtual);
        $stokFinalDoDiaSTMT->execute();

        // if ($stokFinalDoDiaSTMT->rowCount() > 0) {
        //     $row2 = $stokFinalDoDiaSTMT->fetch(PDO::FETCH_ASSOC);
        //     $stokFinalDoDia = $row['stk_inicial_er'];

        //     $updateDemandaStmt->bindParam(':stk_final_er', $stokFinalDoDia);
        // }

        $stokFinalDoDiaSTMT = "SELECT stk_final_enc FROM estoque WHERE produto_id = :produto_id AND dia = :dia";
        $stokFinalDoDiaSTMT = $conexao->prepare($stokFinalDoDiaSTMT);
        $stokFinalDoDiaSTMT->bindParam(':produto_id', $produto_id);
        $stokFinalDoDiaSTMT->bindParam(':dia', $DiaAtual);
        $stokFinalDoDiaSTMT->execute();

        if ($stokFinalDoDiaSTMT->rowCount() > 0) {
            $row3 = $stokFinalDoDiaSTMT->fetch(PDO::FETCH_ASSOC);
            $stokEncomendasFinal = $row3['stk_final_enc'];
        }

        $stk_final_e_virt = $stokFinalDoDia + $stokEncomendasFinal;

        $updateDemandaStmt->bindParam(':stk_final_e_virt', $stk_final_e_virt);


        $updateDemandaStmt->execute();
        $updateDemandaStmt->closeCursor();
    }
}


unset($_SESSION['carrinho']);

header("Location: ./verCarrinho.php?compra=finalizada");
exit;

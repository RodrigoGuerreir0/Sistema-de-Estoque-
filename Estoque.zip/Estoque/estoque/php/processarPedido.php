<?php
session_start();
include('conexao.php');

if (!isset($_GET['id']) || !isset($_GET['acao'])) {
    echo "Parâmetros inválidos.";
    exit;
}

$id = $_GET['id'];
$acao = $_GET['acao'];

$query = "SELECT * FROM encomendas WHERE id = :id";
$stmt = $conexao->prepare($query);
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$encomenda = $stmt->fetch(PDO::FETCH_ASSOC);

if ($encomenda) {
    $status = $acao === 'confirmar' ? 'confirmada' : 'cancelada';

    $insertQuery = "INSERT INTO historico_encomendas (produto_id, usuario_id, quantidade, status, data_encomenda)
                    VALUES (:produto_id, :usuario_id, :quantidade, :status, :data_encomenda)";
    $insertStmt = $conexao->prepare($insertQuery);
    $insertStmt->execute([
        ':produto_id' => $encomenda['produto_id'],
        ':usuario_id' => $encomenda['usuario_id'],
        ':quantidade' => $encomenda['quantidade'],
        ':status' => $status,
        ':data_encomenda' => $encomenda['data_encomenda']
    ]);

    $deleteQuery = "DELETE FROM encomendas WHERE id = :id";
    $deleteStmt = $conexao->prepare($deleteQuery);
    $deleteStmt->bindParam(':id', $id, PDO::PARAM_INT);
    $deleteStmt->execute();

    echo "<script>alert('Pedido $status com sucesso.'); window.location.href = 'administrarPedido.php';</script>";
} else {
    echo "Pedido não encontrado.";
}
?>

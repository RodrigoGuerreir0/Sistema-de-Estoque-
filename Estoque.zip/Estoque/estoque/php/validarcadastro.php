<?php
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $sobrenome = $_POST['sobrenome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $confirmarsenha = $_POST['confirmarsenha'];
    $funcao = "cliente";

    if ($senha !== $confirmarsenha) {
        echo "As senhas não coincidem.";
        exit;
    }

    $sqlVerificaEmail = "SELECT COUNT(*) FROM usuarios WHERE email = :email";
    $stmt = $conexao->prepare($sqlVerificaEmail);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $emailExistente = $stmt->fetchColumn();

    if ($emailExistente > 0) {
        echo "O email já está cadastrado. Tente outro.";
        exit;
    }


    $sql = "INSERT INTO usuarios (nome, sobrenome, email, senha, funcao) VALUES (:nome, :sobrenome, :email, :senha, 'cliente')";

    try {
        $stmt = $conexao->prepare($sql);

        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':sobrenome', $sobrenome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senha);

        if ($stmt->execute()) {
            echo '<script>window.location.href = "../index.php";</script>';
        } else {
            echo "Erro ao realizar cadastro.";
        }
    } catch (PDOException $e) {
        echo "Erro: " . $e->getMessage();
    }
}

<?php
include('conexao.php');

// Obtenha todas as encomendas pendentes
$sql = "SELECT e.id, e.produto_id, e.quantidade, p.quantidade AS quantidade_estoque 
        FROM encomendas e
        JOIN produtos p ON e.produto_id = p.id
        WHERE e.status = 'pendente'";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$encomendas = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($encomendas as $encomenda) {
    $produtoId = $encomenda['produto_id'];
    $quantidadeEncomendada = $encomenda['quantidade'];
    $quantidadeEstoque = $encomenda['quantidade_estoque'];

    if ($quantidadeEncomendada > $quantidadeEstoque) {
        $sqlUpdateEncomenda = "UPDATE encomendas SET status = 'confirmada' WHERE id = :id";
        $stmtUpdateEncomenda = $conexao->prepare($sqlUpdateEncomenda);
        $stmtUpdateEncomenda->execute([':id' => $encomenda['id']]);

        $novaQuantidadeEstoque = $quantidadeEstoque - $quantidadeEncomendada;
        $sqlUpdateProduto = "UPDATE produtos SET quantidade = :novaQuantidade WHERE id = :produtoId";
        $stmtUpdateProduto = $conexao->prepare($sqlUpdateProduto);
        $stmtUpdateProduto->execute([':novaQuantidade' => $novaQuantidadeEstoque, ':produtoId' => $produtoId]);

        $sqlHistorico = "INSERT INTO historico_encomendas (produto_id, usuario_id, quantidade, status, data_encomenda) 
                         SELECT produto_id, usuario_id, quantidade, 'confirmada', data_encomenda FROM encomendas WHERE id = :id";
        $stmtHistorico = $conexao->prepare($sqlHistorico);
        $stmtHistorico->execute([':id' => $encomenda['id']]);

        $dataAtual = date('Y-m-d');
        $sqlUpdateEstoque = "UPDATE estoque SET demanda = demanda + :quantidade 
                             WHERE produto_id = :produtoId AND dia = :dataAtual";
        $stmtUpdateEstoque = $conexao->prepare($sqlUpdateEstoque);
        $stmtUpdateEstoque->execute([':quantidade' => $quantidadeEncomendada, ':produtoId' => $produtoId, ':dataAtual' => $dataAtual]);
    }elseif ($quantidadeEncomendada < $quantidadeEstoque) {

        $sqlUpdateEncomenda = "UPDATE encomendas SET status = 'cancelada' WHERE id = :id";
        $stmtUpdateEncomenda = $conexao->prepare($sqlUpdateEncomenda);
        $stmtUpdateEncomenda->execute([':id' => $encomenda['id']]);

        $sqlHistorico = "INSERT INTO historico_encomendas (produto_id, usuario_id, quantidade, status, data_encomenda) 
                         SELECT produto_id, usuario_id, quantidade, 'confirmada', data_encomenda FROM encomendas WHERE id = :id";
        $stmtHistorico = $conexao->prepare($sqlHistorico);
        $stmtHistorico->execute([':id' => $encomenda['id']]);

        $dataAtual = date('Y-m-d');
        $sqlUpdateEstoque = "UPDATE estoque SET demanda = demanda + :quantidade 
                             WHERE produto_id = :produtoId AND dia = :dataAtual";
        $stmtUpdateEstoque = $conexao->prepare($sqlUpdateEstoque);
        $stmtUpdateEstoque->execute([':quantidade' => $quantidadeEncomendada, ':produtoId' => $produtoId, ':dataAtual' => $dataAtual]);
    }
}

echo '<script>window.location.href = "./gerenciarEncomendas.php";</script>';
exit;
?>

<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "../index.php";</script>';
    exit;
}

$sql = "SELECT e.id, p.nome AS produto_nome, p.preco AS preco_unitario, e.quantidade, e.status, e.data_pedido
        FROM pedidos e
        JOIN produtos p ON e.produto_id = p.id
        ORDER BY e.data_pedido DESC";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$vendas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Vendas</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/logVendas.css">
</head>

<body>

    <header id="header">

        <nav id="nav">
            <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
                <span id="hambuguer"></span>
            </buttton>


            <?php if ($_SESSION['funcao'] == 'cliente') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Página Inicial</a></li>
                    <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                    <li><a href="../php/verCarrinho.php">Carrinho</a></li>
                </ul>
            <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
                <ul id="menu" role="menu">
                    <!-- <li><a href="../php/paginainicial.php">Página Inicial</a></li> -->
                    <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
                    <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
                    <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
                    <li><a href="./logVendas.php">Histórico de Vendas</a></li>
                    <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
                    <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
                    <li><a href="./encomendarProduto.php">Encomendar Produtos</a></li>

                </ul>

            <?php } else {
                echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
                exit;
            } ?>
        </nav>
        <div id="header-title">Histórico de Vendas</div>
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs//home.png" alt=""></a></button>

    </header>

    <main>

        <table>
            <thead>
                <tr>
                    <th>ID da Venda</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Preço Unitário (R$)</th>
                    <th>Valor Total (R$)</th>
                    <th>Status</th>
                    <th>Data da Venda</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($vendas as $venda):
                    // Calcula o valor total (preço unitário * quantidade)
                    $valor_total = $venda['preco_unitario'] * $venda['quantidade'];
                ?>
                    <tr>
                        <td><?php echo $venda['id']; ?></td>
                        <td><?php echo htmlspecialchars($venda['produto_nome']); ?></td>
                        <td><?php echo $venda['quantidade']; ?></td>
                        <td>R$ <?php echo number_format($venda['preco_unitario'], 2, ',', '.'); ?></td>
                        <td>R$ <?php echo number_format($valor_total, 2, ',', '.'); ?></td>
                        <td class="<?php
                                    if ($venda['status'] == 'confirmada') {
                                        echo 'status-confirmada';
                                    } elseif ($venda['status'] == 'cancelada') {
                                        echo 'status-cancelada';
                                    } else {
                                        echo 'status-pendente';
                                    }
                                    ?>">
                            <?php echo ucfirst($venda['status']); ?>
                        </td>
                        <td><?php echo date('d/m/Y', strtotime($venda['data_pedido'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>


    </main>

</body>
<script src="../script/hamburguer.js"></script>
</html>
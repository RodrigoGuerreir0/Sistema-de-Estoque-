<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "../index.php";</script>';
    exit;
}

function exibirDataAtual($conexao)
{
    $query = "SELECT data_atual FROM controle_data ORDER BY id DESC LIMIT 1";
    $stmt = $conexao->prepare($query);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
    } else {
    }
}

function calcularConsumoMedio($conexao, $produto_id)
{
    $query = "SELECT quantidade FROM pedidos WHERE produto_id = :produto_id ORDER BY data_pedido DESC";
    $stmt = $conexao->prepare($query);
    $stmt->execute([':produto_id' => $produto_id]);
    $demandas = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $stmt->closeCursor();

    if (count($demandas) > 0) {
        $somaDemandas = array_sum($demandas);
        $dias = count($demandas);
        $Medio = ceil($somaDemandas / $dias);
    } else {
        $Medio = 0;
    }

    return $Medio;
}

function calcularConsumoMaximo($conexao, $produto_id, $dias = 3)
{
    $query = "SELECT MAX(quantidade) FROM (SELECT quantidade 
                    FROM pedidos 
                    WHERE produto_id = :produto_id 
                    ORDER BY data_pedido DESC 
                    LIMIT :dias) AS ultimos_dias";
    $stmt = $conexao->prepare($query);
    $stmt->bindParam(':produto_id', $produto_id, PDO::PARAM_INT);
    $stmt->bindParam(':dias', $dias, PDO::PARAM_INT);
    $stmt->execute();
    $maiorQuantidade = $stmt->fetchColumn();
    $stmt->closeCursor();

    return $maiorQuantidade ? (int)$maiorQuantidade : 0;
}

function calcularConsumoTotal($conexao, $produto_id)
{
    $query = "SELECT SUM(quantidade) AS totalQuantidade 
              FROM pedidos 
              WHERE produto_id = :produto_id";

    $stmt = $conexao->prepare($query);
    $stmt->bindParam(':produto_id', $produto_id, PDO::PARAM_INT);
    $stmt->execute();
    $totalQuantidade = $stmt->fetchColumn();
    $stmt->closeCursor();

    return $totalQuantidade ? (int)$totalQuantidade : 0;
}

function avancarDia($conexao)
{
    $PP = 0;
    $LECF = 0;
    $LEC = 0;


    $query = "SELECT data_atual FROM controle_data ORDER BY id DESC LIMIT 1";
    $stmt = $conexao->prepare($query);
    $stmt->execute();
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $stmt->closeCursor();

    $novaData = $data ? date('Y-m-d', strtotime($data['data_atual'] . ' +1 day')) : date('Y-m-d');

    if (empty($dia)) {
        if (!empty($data['data_atual'])) {
            $dia = date('d', strtotime($data['data_atual'])) + 1;
        } else {
            $dia = 1;
        }
    }


    $insertQuery = "INSERT INTO controle_data (data_atual) VALUES (:data_atual)";
    $insertStmt = $conexao->prepare($insertQuery);
    $insertStmt->bindParam(':data_atual', $novaData);
    $insertStmt->execute();
    $insertStmt->closeCursor();

    $produtoQuery = "SELECT * FROM produtos";
    $produtos = $conexao->query($produtoQuery)->fetchAll(PDO::FETCH_ASSOC);

    foreach ($produtos as $produto) {
        $produto_id = $produto['id'];
        $produto_nome = $produto['nome'];
        $preco = $produto['preco'];
        $stk_inicial_er = $produto['quantidade'];

        $encomendaAnteriorQuery = "SELECT stk_final_enc FROM estoque 
                                   WHERE produto_id = :produto_id 
                                   ORDER BY dia DESC LIMIT 1";
        $encomendaAnteriorStmt = $conexao->prepare($encomendaAnteriorQuery);
        $encomendaAnteriorStmt->execute([':produto_id' => $produto_id]);
        $stk_inicial_enc = (int)$encomendaAnteriorStmt->fetchColumn();
        $encomendaAnteriorStmt->closeCursor();

        $encomendaVirtQuery = "SELECT SUM(quantidade) AS total FROM pedidos 
                               WHERE produto_id = :produto_id 
                               AND status = 'pendente'";
        $encomendaVirtStmt = $conexao->prepare($encomendaVirtQuery);
        $encomendaVirtStmt->execute([':produto_id' => $produto_id]);
        $stk_inicial_e_virt = $stk_inicial_er + $stk_inicial_enc;
        $encomendaVirtStmt->closeCursor();

        $produtoDaDemanda = "SELECT SUM(quantidade) FROM pedidos WHERE produto_id = :produto_id AND data_pedido = :dia";
        $demandaDeProdutosStmt = $conexao->prepare($produtoDaDemanda);
        $demandaDeProdutosStmt->execute([':produto_id' => $produto_id, ':dia' => $novaData]);
        $demanda = (int)$demandaDeProdutosStmt->fetchColumn();
        $demandaDeProdutosStmt->closeCursor();

        $produtoDasVendasEfetivas = "SELECT SUM(quantidade) FROM pedidos WHERE status = 'confirmada' AND produto_id = :produto_id AND data_pedido = :dia";
        $VendaEfetivaSTMT = $conexao->prepare($produtoDasVendasEfetivas);
        $VendaEfetivaSTMT->execute([':produto_id' => $produto_id, ':dia' => $novaData]);
        $venda_efetiva = (int)$VendaEfetivaSTMT->fetchColumn();
        $VendaEfetivaSTMT->closeCursor();

        $venda_perdida = $demanda - $venda_efetiva;

        $ConsumoMedio = calcularConsumoMedio($conexao, $produto_id);

        $ConsumoMaximo = calcularConsumoMaximo($conexao, $produto_id, $dias = 3);

        $ConsumoMaximoDoDia =  calcularConsumoTotal($conexao, $produto_id);

        $TR = 3;

        $EstoqueSegurança = ($ConsumoMaximo - $ConsumoMedio) * $TR;

        $PP = ($ConsumoMedio * $TR) + $EstoqueSegurança;

        $cp = 800;
        $ca = 75;
        $cf = 150;

        $LEC = ((2 * $cp) * $ConsumoMaximoDoDia) / $ca;

        $formulaLECF = ($ca + $cf) / $cf;

        $LECF = floor(sqrt($LEC) * sqrt($formulaLECF));

        $compras = 0;


        // echo '<br> <br> <br> <br> <br> <br> <br> <br> DIA: ', $dia;
        // echo '<br> PP: ', $PP;
        // echo '<br>', $LECF;
        // echo '<br> LEC: ', $LEC;




        if ($dia % 5 == 0 && $stk_inicial_er > $PP) {

            $sql = "INSERT INTO historico_encomendas 
                    (produto_id, usuario_id, CompraAutomatica, quantidade, statusDaEncomenda, data_encomenda, data_chegada) 
                    VALUES (:produto_id, 1, 'Sim', :quantidade, 'A caminho', :data_encomenda, :data_chegada)";
            $stmt = $conexao->prepare($sql);

            $data_chegada = date('Y-m-d', strtotime($novaData . ' +4 days'));

            $stmt->bindParam(':produto_id', $produto_id);
            $stmt->bindParam(':quantidade', $LEC);
            $stmt->bindParam(':data_encomenda', $novaData);
            $stmt->bindParam(':data_chegada', $data_chegada);
            $stmt->execute();
        }

        if ($LECF == 0 || $LECF < $PP) {

            $compras = $LECF;

            $sql = "INSERT INTO historico_encomendas (produto_id, usuario_id, CompraAutomatica, quantidade, statusDaEncomenda, data_encomenda, data_chegada) VALUES (:produto_id, 1, :CompraAutomatica, :quantidade, :statusDaEncomenda, :data_encomenda, :data_chegada)";
            $stmt = $conexao->prepare($sql);

            $compraAutomatica = 'Sim';
            $statusDaEncomenda = 'A caminho';
            $data_chegada = date('Y-m-d', strtotime($novaData . ' +4 days'));

            $stmt->bindParam(':produto_id', $produto_id);
            $stmt->bindParam(':CompraAutomatica', $compraAutomatica);
            $stmt->bindParam(':quantidade', $compras);
            $stmt->bindParam(':statusDaEncomenda', $statusDaEncomenda);
            $stmt->bindParam(':data_encomenda', $novaData);
            $stmt->bindParam(':data_chegada', $data_chegada);
            $stmt->execute();
        }

        $encomendasHojeQuery = "SELECT produto_id, quantidade FROM historico_encomendas 
                                WHERE data_chegada = :data_hoje AND statusDaEncomenda = 'A caminho'";
        $encomendasHojeStmt = $conexao->prepare($encomendasHojeQuery);
        $encomendasHojeStmt->bindParam(':data_hoje', $novaData);
        $encomendasHojeStmt->execute();
        $encomendasHoje = $encomendasHojeStmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($encomendasHoje as $encomenda) {
            $produto_id = $encomenda['produto_id'];
            $quantidade = $encomenda['quantidade'];

            $updateEstoqueQuery = "UPDATE produtos SET quantidade = quantidade + :quantidade WHERE id = :produto_id";
            $updateEstoqueStmt = $conexao->prepare($updateEstoqueQuery);
            $updateEstoqueStmt->bindParam(':quantidade', $quantidade);
            $updateEstoqueStmt->bindParam(':produto_id', $produto_id);
            $updateEstoqueStmt->execute();

            $updateEncomendaQuery = "UPDATE historico_encomendas SET statusDaEncomenda = 'Recebida' WHERE produto_id = :produto_id AND data_chegada = :data_hoje";
            $updateEncomendaStmt = $conexao->prepare($updateEncomendaQuery);
            $updateEncomendaStmt->bindParam(':produto_id', $produto_id);
            $updateEncomendaStmt->bindParam(':data_hoje', $novaData);
            $updateEncomendaStmt->execute();
        }

        $stk_final_er = $stk_inicial_er - $venda_efetiva;
        if ($stk_final_er >= 0) {
            $stk_final_er = $stk_final_er;
        } else {
            $stk_final_er = 0;
        }

        $query = "SELECT SUM(quantidade) as total_encomendas_3dias 
        FROM historico_encomendas 
        WHERE produto_id = :produto_id AND statusDaEncomenda = 'A caminho'";

        $stmt = $conexao->prepare($query);
        $stmt->bindParam(':produto_id', $produto_id, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stk_final_enc3Dias = $result['total_encomendas_3dias'] ?? 0;

        $stk_final_enc = $stk_final_enc3Dias;

        $stk_final_e_virt = $stk_final_er + $stk_final_enc;

        $custo_total = $preco * $compras;

        $balancoQuery = "INSERT INTO estoque 
                        (produto_id, produto_nome, dia, stk_inicial_er, stk_inicial_enc, stk_inicial_e_virt,
                         venda_efetiva, venda_perdida, demanda, compras,
                         stk_final_er, stk_final_enc, stk_final_e_virt, custo_unitario, custo_total)
                        VALUES (:produto_id, :produto_nome, :dia, :stk_inicial_er, :stk_inicial_enc, :stk_inicial_e_virt,
                                :venda_efetiva, :venda_perdida, :demanda, :compras,
                                :stk_final_er, :stk_final_enc, :stk_final_e_virt, :custo_unitario, :custo_total)";
        $balancoStmt = $conexao->prepare($balancoQuery);
        $balancoStmt->execute([
            ':produto_id' => $produto_id,
            ':produto_nome' => $produto_nome,
            ':dia' => $novaData,
            ':stk_inicial_er' => $stk_inicial_er,
            ':stk_inicial_enc' => $stk_inicial_enc,
            ':stk_inicial_e_virt' => $stk_inicial_e_virt,
            ':venda_efetiva' => 0,
            ':venda_perdida' => 0,
            ':demanda' => 0,
            ':compras' => $compras,
            ':stk_final_er' => $stk_final_er,
            ':stk_final_enc' => $stk_final_enc,
            ':stk_final_e_virt' => $stk_final_e_virt,
            ':custo_unitario' => $preco,
            ':custo_total' => $custo_total
        ]);
        $balancoStmt->closeCursor();
    }
}

function exibirEstoque($conexao, $produto_id = null, $dia = null)
{
    $query = "SELECT * FROM estoque WHERE 1=1";
    if ($produto_id) {
        $query .= " AND produto_id = :produto_id";
    }
    if ($dia) {
        $query .= " AND dia = :dia";
    }
    $query .= " ORDER BY dia DESC";

    $stmt = $conexao->prepare($query);
    if ($produto_id) {
        $stmt->bindParam(':produto_id', $produto_id, PDO::PARAM_INT);
    }
    if ($dia) {
        $stmt->bindParam(':dia', $dia);
    }
    $stmt->execute();
    $estoque = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<table border='1'>
            <tr>
                <th>Produto</th>
                <th>Dia</th>
                <th>Estoque Inicial</th>
                <th>Encomendas Iniciais</th>
                <th>Estoque Virtual Inicial</th>
                <th>Venda Efetiva</th>
                <th>Venda Perdida</th>
                <th>Demanda</th>
                <th>Compras</th>
                <th>Estoque Final</th>
                <th>Encomendas Finais</th>
                <th>Estoque Virtual Final</th>
                <th>Custo Unitário</th>
                <th>Custo Total</th>
            </tr>";

    foreach ($estoque as $linha) {
        echo "<tr>
                <td>{$linha['produto_nome']}</td>
                <td>{$linha['dia']}</td>
                <td>{$linha['stk_inicial_er']}</td>
                <td>{$linha['stk_inicial_enc']}</td>
                <td>{$linha['stk_inicial_e_virt']}</td>
                <td>{$linha['venda_efetiva']}</td>
                <td>{$linha['venda_perdida']}</td>
                <td>{$linha['demanda']}</td>
                <td>{$linha['compras']}</td>
                <td>{$linha['stk_final_er']}</td>
                <td>{$linha['stk_final_enc']}</td>
                <td>{$linha['stk_final_e_virt']}</td>
                <td>{$linha['custo_unitario']}</td>
                <td>{$linha['custo_total']}</td>
              </tr>";
    }
    echo "</table>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['avancar_dia'])) {
    avancarDia($conexao);
}

$produto_id = $_POST['produto_id'] ?? null;
$dia = $_POST['dia'] ?? null;

$produtos = $conexao->query("SELECT id, nome FROM produtos")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/balancoGeral.css">
    <title>Gestão de Estoque</title>
    <style>

    </style>
</head>

<body>

    <header id="header">

        <nav id="nav">
            <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
                <span id="hambuguer"></span>
            </buttton>


            <?php if ($_SESSION['funcao'] == 'cliente') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Página Inicial</a></li>
                    <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                    <li><a href="../php/verCarrinho.php">Carrinho</a></li>
                </ul>
            <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
                <ul id="menu" role="menu">
                    <!-- <li><a href="../php/paginainicial.php">Página Inicial</a></li> -->
                    <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
                    <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
                    <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
                    <li><a href="./logVendas.php">Histórico de Vendas</a></li>
                    <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
                    <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
                    <li><a href="./encomendarProduto.php">Encomendar Produtos</a></li>
                </ul>
            <?php } else {
                echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
                exit;
            } ?>
        </nav>
        <div id="header-title">Gestão de Estoque</div>
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs/home.png" alt=""></a></button>

    </header>

    <div class="container">
        <div>
            <?php exibirDataAtual($conexao); ?>
        </div>


        <div class="centralizar__main">
            <div class="centralizar1">
                <form action="" method="post" class="mt-4">
                    <div class="centralizarFiltros">
                        <div class="form-group">
                            <label for="produto_id">Filtrar por Produto:</label>
                            <select name="produto_id" id="produto_id" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($produtos as $produto): ?>
                                    <option value="<?= $produto['id'] ?>" <?= $produto_id == $produto['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($produto['nome']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                    </div>
                    <div class="form-group mt-2">
                        <label for="dia">Filtrar por Data:</label>
                        <input type="date" name="dia" id="dia" class="form-control" value="<?= htmlspecialchars($dia) ?>">
                    </div>

                    <button class="btnFiltrar mt-3" type="submit" value=""> <b> FILTRAR </b></button>
                </form>
            </div>
            <div class="centralizar2">
                <form class="botoesFA" action="" method="post">
                    <button class="btnFuncoes" type="submit" name="avancar_dia"><b>Finalizar o Dia</b></button>
                    <button class="btnFuncoes" type="submit" name="atualizar_estoque"><b>Atualizar Estoque</b></button>
                </form>
            </div>
        </div>
        <div class="table-responsive tabelaEspaco">
            <?php exibirEstoque($conexao, $produto_id, $dia); ?>
        </div>
        <div class="centralizarPDF">
            <a class="btnRelatorio" href="../pdf/gerar/index.php"><img class="imgBaixar" src="../imgs/baixar.png" alt="Gerar PDF"> <span><b>Gerar PDF</b></span></a>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="../script/hamburguer.js"></script>
</body>

</html>
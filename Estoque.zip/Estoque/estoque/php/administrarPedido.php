<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "./paginainicial.php";</script>';
    exit;
}

$sql = "SELECT e.id, p.nome AS produto_nome, u.nome AS usuario_nome, e.quantidade, e.status, e.data_pedido 
        FROM encomendas e 
        JOIN produtos p ON e.produto_id = p.id
        JOIN usuarios u ON e.usuario_id = u.id
        WHERE e.status = 'pendente'";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$encomendas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Encomendas</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>

    <h1>Gerenciar Encomendas Pendentes</h1>

    <?php if (empty($encomendas)): ?>
        <p>Não há pedidos pendentes.</p>
        <div><a href="./paginainicial.php">Página Inicial</a></div>
        <div><a href="./logVendas.php">Histórico de Vendas</a></div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Usuário</th>
                    <th>Quantidade</th>
                    <th>Status</th>
                    <th>Data da Encomenda</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($encomendas as $encomenda): ?>
                    <tr>
                        <td><?php echo $encomenda['id']; ?></td>
                        <td><?php echo $encomenda['produto_nome']; ?></td>
                        <td><?php echo $encomenda['usuario_nome']; ?></td>
                        <td><?php echo $encomenda['quantidade']; ?></td>
                        <td><?php echo $encomenda['status']; ?></td>
                        <td><?php echo date('d/m/Y H:i:s', strtotime($encomenda['data_pedido'])); ?></td>
                        <td>
                            <a href="processarPedido.php?id=<?php echo $encomenda['id']; ?>&acao=confirmar">Confirmar</a> |
                            <a href="processarPedido.php?id=<?php echo $encomenda['id']; ?>&acao=cancelar">Cancelar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div><a href="./encomendarProduto.php">Encomendar Produtos</a></div>
    <?php endif; ?>

</body>
</html>

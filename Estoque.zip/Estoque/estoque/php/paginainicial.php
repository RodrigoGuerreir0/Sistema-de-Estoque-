<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Inicial</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/PaginaInicial.css">

</head>

<body>
    <div class="sidebar">
        <?php if ($_SESSION['funcao'] == 'cliente') { ?>
            <h1>Bem-vindo, Cliente</h1>
            <a href="./verCarrinho.php">Carrinho</a>
            <a href="./adicionarProdutoCarrinho.php">Fazer Pedido</a>
            <a href="./statusPedidos.php">Meus Pedidos</a>
            <div class="logCliente">
                <button class="logout" onclick="window.location.href='./deslogar.php'">
                    <img src="../imgs/Sair.png" class="imgSair"> Sair
                </button>
            </div>
        <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
            <h1>Acesso Administrador</h1>
            <!-- <a href="./verCarrinho.php">Carrinho</a> -->
            <a href="./verificarProdutos.php">Verificar Produtos</a>
            <a href="./inserirProduto.php">Inserir Produtos</a>
            <a href="./logVendas.php">Histórico de Vendas</a>
            <a href="./balancoGeral.php">Balanço Geral</a>
            <a href="./cadastrarFornecedor.php">Cadastrar Fornecedor</a>
            <a href="./encomendarProduto.php">Encomendar Produtos</a>
            <div class="logADM">
                <button class="logout" onclick="window.location.href='./deslogar.php'">
                    <img src="../imgs/Sair.png" class="imgSair"> Sair
                </button>
            </div>
        <?php } else {
            echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
            exit;
        } ?>



    </div>

    <div class="content">
        <h1>
            <?php
            echo ($_SESSION['funcao'] == 'cliente') ? 'Bem-vindo ao Sistema!' : 'Painel Administrativo';
            ?>
        </h1>
        <p>Escolha uma das opções ao lado para navegar pelo sistema.</p>
    </div>
</body>

</html>
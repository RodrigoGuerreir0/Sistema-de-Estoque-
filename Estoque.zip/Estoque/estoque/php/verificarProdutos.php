<?php
include 'conexao.php';

session_start();

if (!isset($_SESSION['email'])) {
    echo '<script>alert("Você precisa estar logado para acessar esta página."); window.location.href = "../index.php";</script>';
    exit;
}
if (!isset($_SESSION['id']) || $_SESSION['funcao'] !== 'administrador') {
    echo '<script>window.location.href = "./paginainicial.php";</script>';
    exit;
}
$sql = "SELECT * FROM produtos";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Produtos</title>
    <link rel="stylesheet" href="../css/verificarProdutos.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<style>

</style>

<body>
    <!-- <div class="colocarProduto">
        <div class="btnColocarProduto">
            <a href="./inserirProduto.php"><span class="MAIS">+</span> <span>Inserir Produtos</span></a>
        </div>
    </div> -->
    <header id="header">

        <nav id="nav">
            <buttton id="btn-mobile" aria-label="Abrir menu" aria-haspopup="true" aria-controls="menu" aria-expanded="false">
                <span id="hambuguer"></span>
            </buttton>


            <?php if ($_SESSION['funcao'] == 'cliente') { ?>
                <ul id="menu" role="menu">
                    <li><a href="../php/paginainicial.php">Página Inicial</a></li>
                    <li><a href="../php/adicionarProdutoCarrinho.php">Fazer Pedido</a></li>
                    <li><a href="../php/statusPedidos.php">Meus Pedidos</a></li>
                    <li><a href="../php/verCarrinho.php">Carrinho</a></li>
                </ul>
            <?php } else if ($_SESSION['funcao'] == 'administrador') { ?>
                <ul id="menu" role="menu">
                    <!-- <li><a href="../php/paginainicial.php">Página Inicial</a></li> -->
                    <!-- <li><a href="../php/verCarrinho.php">Carrinho</a></li> -->
                    <li><a href="../php/verificarProdutos.php">Verificar Produtos</a></li>
                    <li><a href="../php/inserirProduto.php">Inserir Produtos</a></li>
                    <li><a href="./logVendas.php">Histórico de Vendas</a></li>
                    <li><a href="../php/balancoGeral.php">Balanço Geral</a></li>
                    <li><a href="../php/cadastrarFornecedor.php">Cadastrar Fornecedor</a></li>
                    <li><a href="./encomendarProduto.php">Encomendar Produtos</a></li>
                </ul>

            <?php } else {
                echo '<script>alert("Função inválida."); window.location.href = "../index.php";</script>';
                exit;
            } ?>
        </nav>
        <div id="header-title">Produtos Cadastrados</div>
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs/home.png" alt=""></a></button>

    </header>

    <main>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Quantidade</th>
                    <th>Fornecedor</th>
                    <th>Preço (R$)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produtos as $produto): ?>
                    <tr>
                        <td><?php echo $produto['id']; ?></td>
                        <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                        <td><?php echo $produto['quantidade']; ?></td>
                        <td><?php echo $produto['fornecedor']; ?></td>
                        <td>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></td>
                        <td class="actions">
                            <a href="editarProduto.php?id=<?php echo $produto['id']; ?>">Editar</a>
                            <button type="submit" onclick="confirmarExclusao(<?php echo $produto['id']; ?>)" class="btn"><img class="lixeira" src="../imgs/lixo.png" alt=""></button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="links">
            <a href="./inserirProduto.php">Inserir Produtos</a>

        </div>
    </main>
    <script>
        function confirmarExclusao(id) {
            Swal.fire({
                title: 'Tem certeza?',
                text: "Esta ação não poderá ser desfeita!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#005f6b',
                cancelButtonColor: '#008c9e',
                confirmButtonText: 'Sim, excluir',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "excluirProduto.php?id=" + id;
                }
            });
        }
    </script>

</body>
<script src="../script/hamburguer.js"></script>

</html>
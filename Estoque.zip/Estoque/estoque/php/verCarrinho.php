<?php
session_start();

$total = 0;
$carrinhoVazio = !isset($_SESSION['carrinho']) || empty($_SESSION['carrinho']);

// Verifica se há um pedido de exclusão
if (isset($_POST['remover_id'])) {
    $removerId = $_POST['remover_id'];

    // Filtra o carrinho para remover o item com o ID correspondente
    $_SESSION['carrinho'] = array_filter($_SESSION['carrinho'], function ($item) use ($removerId) {
        return $item['id'] !== $removerId;
    });

    // Reindexa os índices do carrinho para evitar problemas
    $_SESSION['carrinho'] = array_values($_SESSION['carrinho']);
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/carrinho.css">
    <title>Carrinho de Compras</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="btnVoltar">
        <button class="btnVoltarBTN"><a class="btnVoltarA" href="../php/paginainicial.php"><img class="btnVoltarIMG" src="../imgs/home.png" alt=""></a></button>
    </div>



    <div class="centro">
        <div class="container">
            <h1>Carrinho de Compras</h1>

            <?php if ($carrinhoVazio): ?>
                <p>Carrinho vazio!</p>
                <a href="./adicionarProdutoCarrinho.php" class="btn">Escolher produtos</a>
                <a href="./statusPedidos.php" class="btn">Meus Pedidos</a>
            <?php else: ?>
                <div class="cart-table-container">
                    <table class="cart-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Preço Unitário (R$)</th>
                                <th>Quantidade</th>
                                <th>Subtotal (R$)</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($_SESSION['carrinho'] as $item): ?>
                                <tr>
                                    <td><?php echo $item['id']; ?></td>
                                    <td><?php echo $item['nome']; ?></td>
                                    <td><?php echo number_format($item['preco'], 2, ',', '.'); ?></td>
                                    <td><?php echo $item['quantidade']; ?></td>
                                    <td>
                                        <?php
                                        $subtotal = $item['preco'] * $item['quantidade'];
                                        $total += $subtotal;
                                        echo number_format($subtotal, 2, ',', '.');
                                        ?>
                                    </td>
                                    <td>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="remover_id" value="<?php echo $item['id']; ?>">
                                            <button type="submit" class="remove-btn">
                                                🗑️
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <p class="total">Total: R$ <?php echo number_format($total, 2, ',', '.'); ?></p>

                <div style="text-align: center;">
                    <a href="./adicionarProdutoCarrinho.php" class="btn">Continuar Encomendando</a>
                    <button onclick="confirmarCompra()" class="btn">Finalizar Compra</button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (isset($_GET['compra']) && $_GET['compra'] === 'finalizada'): ?>
        <script>
            Swal.fire({
                title: 'Compra Finalizada!',
                text: 'Acompanhe o status na sua página de pedidos.',
                icon: 'success',
                confirmButtonColor: '#005f6b',
                confirmButtonText: 'OK'
            });
        </script>
    <?php endif; ?>

    <script>
        function confirmarCompra() {
            Swal.fire({
                title: 'Confirmar Compra?',
                text: "Você deseja finalizar a compra?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#005f6b',
                cancelButtonColor: '#008c9e',
                confirmButtonText: 'Sim, confirmar compra!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "finalizarCompra.php";
                }
            });
        }
    </script>
</body>

</html>
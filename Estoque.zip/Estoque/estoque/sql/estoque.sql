CREATE DATABASE IF NOT EXISTS Estoque;
USE Estoque;

CREATE TABLE IF NOT EXISTS fornecedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cnpj VARCHAR(18) UNIQUE NOT NULL,
    endereco VARCHAR(255),
    telefone VARCHAR(20),
    email VARCHAR(100) UNIQUE
);

INSERT INTO fornecedores (nome, cnpj, endereco, telefone, email) 
VALUES ('Coca Cola', '00.000.000/0000-00', 'Rua Do não sei', '(78) 95421-2012', 'coca@gmail.com');

CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL DEFAULT 0,
    fornecedor VARCHAR(100),
    preco DECIMAL(10, 2) NOT NULL
);

INSERT INTO produtos (nome, quantidade, fornecedor, preco) 
VALUES ('Agua', '150', 'Coca Cola', '5,99');

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    funcao ENUM('administrador', 'cliente') NOT NULL
);

INSERT INTO usuarios (nome, sobrenome, email, senha, funcao) 
VALUES ('Rodrigo', 'Guerreiro', 'admim@gmail.com', 'admim', 'administrador');

CREATE TABLE IF NOT EXISTS controle_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data_atual DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    usuario_id INT NOT NULL,
    quantidade INT NOT NULL,
    status ENUM('pendente', 'confirmada', 'cancelada') DEFAULT 'pendente',
    data_pedido Date,
    notificado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS historico_encomendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    usuario_id INT NOT NULL,
    CompraAutomatica ENUM('Sim', 'Não'),
    quantidade INT NOT NULL,
    statusDaEncomenda varchar(50) NOT NULL,
    data_encomenda date,
    data_chegada date,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS estoque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    produto_nome VARCHAR(255) NOT NULL DEFAULT 'Vazio',
    dia date,
    stk_inicial_er INT NOT NULL DEFAULT 0,
    stk_inicial_enc INT NOT NULL DEFAULT 0,
    stk_inicial_e_virt INT NOT NULL DEFAULT 0,
    venda_efetiva INT NOT NULL DEFAULT 0,
    venda_perdida INT NOT NULL DEFAULT 0,
    demanda INT NOT NULL DEFAULT 0,
    compras INT NOT NULL DEFAULT 0,
    stk_final_er INT NOT NULL DEFAULT 0,
    stk_final_enc INT NOT NULL DEFAULT 0,
    stk_final_e_virt INT NOT NULL DEFAULT 0,
    custo_unitario DECIMAL(10, 2) NOT NULL,
    custo_total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE
);

SELECT * FROM produtos;
SELECT * FROM estoque;
SELECT * FROM controle_data;
SELECT * FROM usuarios;
SELECT * FROM historico_encomendas;
SELECT * FROM pedidos;
SELECT * FROM fornecedores;

-- drop database Estoque;?